

# here is our program code
print "Hello bash!"
print "The shell needs to know what program should execute the script!"