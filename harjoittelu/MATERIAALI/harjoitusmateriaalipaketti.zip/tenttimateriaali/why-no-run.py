#!/usr/bin/env python
print "Yay!  It works!"
